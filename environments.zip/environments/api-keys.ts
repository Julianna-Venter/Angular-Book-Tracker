export const API_KEYS = {
  firestore: 'AIzaSyCYLhWEznOfFADVlrlSTSBzQTBrin_IDwc',
  google: 'AIzaSyBfUD4CCh8I_kxFc4XpXcEMUQCID4fRy00',
};
